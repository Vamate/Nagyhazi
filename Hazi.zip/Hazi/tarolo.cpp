#include "tarolo.h"
#include <fstream>
#include <iostream>
#include "memtrace.h"

using namespace std;

void AlakzatTarolo::add(Alakzat* a) {
    Alakzat** ujtomb = new Alakzat*[this->num + 1];
    for(int i = 0; i < this->num; i++) ujtomb[i] = this->tomb[i];
    ujtomb[this->num] = a;
    if(num > 0) delete[] tomb;
    this->num += 1;
    this->tomb = ujtomb;
}

void AlakzatTarolo::kivesz(int index) {
    if(num > 1) {
        Alakzat** ujtomb = new Alakzat*[this->num - 1];
        for(int i = 0; i < index; i++) ujtomb[i] = this->tomb[i];
        for(int i = index+1; i < this->num; i++) ujtomb[i-1] = this->tomb[i];
        delete tomb[index];
        delete[] tomb;
        this->num -= 1;
        this->tomb = ujtomb;
    } else if(num == 1) {
        delete tomb[index];
        delete[] tomb;
        num = 0;
    }

}

void AlakzatTarolo::beolvas(const char* f) {
    for(int i = 0; i < this->num; i++) delete tomb[i];
    if(num > 0) delete[] tomb;
    num = 0;
    hozzaolvas(f);
}

void AlakzatTarolo::hozzaolvas(const char* f) {
    std::ifstream file(f);
    if(file.is_open()){
        for(Alakzat* a = beolvas_egyet(file); a != NULL; a = beolvas_egyet(file))
            add(a);
        file.close();
    }
}

void AlakzatTarolo::kiir(const char* f) {
    std::ofstream file(f);
    if(file.is_open()){
        for(int i = 0; i < this->num; i++) tomb[i]->save(file);
        file.close();
    }
}

void AlakzatTarolo::kiirkonzol() {
        for(int i = 0; i < this->num; i++) tomb[i]->kiir(std::cout);
}

Alakzat* AlakzatTarolo::beolvas_egyet(std::istream& is) {
    std::string tipus;
    if (!(is >> tipus))
        return NULL;
    Alakzat* uj;
    if(tipus == "rectangle"){
        uj = new Negyzet;
    }
    else if(tipus == "triangle") {
        uj = new Haromszog;
    }
    else if(tipus == "circle") {
        uj = new Kor;
    } else {
        return NULL;
    }
    uj->load(is);
    return uj;
}

void AlakzatTarolo::szurKorTart(Kor& k) {
    bool vege = false; int i = 0;
    while(vege == false) {
        bool talalt = false;
        while(talalt == false) {
            if(i == num) {
                talalt = true; vege = true;
            }else if(!tomb[i]->inKor(k)) {
                talalt = true; kivesz(i); i = 0;
            } else {
                i++; if(i == num) {
                    talalt = true; vege = true;
                }
            }
        }
    }

}

void AlakzatTarolo::szurKorTart(Pont& kp, double sugar) {
    Kor k(kp, sugar);
    szurKorTart(k);
}

void AlakzatTarolo::szurPontTart(Pont& p) {
    bool vege = false; int i = 0;
    while(vege == false) {
        bool talalt = false;
        while(talalt == false) {
            if(i == num) {
                talalt = true; vege = true;
            }else if(!tomb[i]->tartalmaz(p)) {
                talalt = true; kivesz(i); i = 0;
            } else {
                i++; if(i == num) {
                    talalt = true; vege = true;
                }
            }
        }
    }

}

AlakzatTarolo::~AlakzatTarolo() {
    for(int i = 0; i < num; ++i) delete tomb[i];
    if(num > 0) delete[] tomb;
}
