#include "tester.h"
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

bool Tester::test(const char* p1, const char* p2) {
    ostringstream os1, os2; ifstream file; char s[200];
    file.open(p1);
	if(file){
        while(file.eof()==0){
            file>>s;
            os1<<s<<" ";
        }
        os1<<"\n";
        file.close();
    }
    file.open(p2);
	if(file){
        while(file.eof()==0){
            file>>s;
            os2<<s<<" ";
        }
        os2<<"\n";
        file.close();
    }
    cout<<"\n\nKimenet:\n"<<os1.str()<<endl;
    cout<<"-----------\nElv�rt kimenet:\n"<<os2.str()<<endl;
    return (os1.str() == os2.str());
}
