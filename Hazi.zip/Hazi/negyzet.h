#ifndef NEGYZET_H
#define NEGYZET_H
#include "alakzat.h"

class Pont;
class Kor;

/*! Négyzet osztály, Alakzatból származtatott. */
class Negyzet : public Alakzat{
private:
    Pont* csucsok;
public:
    Negyzet();//!< Alapértelmezett konstruktor.
    Negyzet(Pont& kp, Pont& cs);//!< Konstruktor középpontal és egy csúccsal.
    void data(Pont& kp, Pont& cs);//!< Négyzet középpontjából és egy csúcsából a többi csúcs kiszámítása.
    virtual bool inKor(Pont& kp, double sugar);//!< Megmondja, hogy a négyzet benne van-e egy körben.
    virtual bool inKor(Kor& k);//!< Megmondja, hogy a négyzet benne van-e egy körben.
    virtual bool tartalmaz(Pont& p);//!< Megmondja, hogy a négyzet tartalmaz-e egy pontot.
    Pont operator [](int i) const {return csucsok[i];}//!< Indexelõ operátor visszaadja a négyzet adott csúcsát.
    void kiir(std::ostream& os) const;//!< Kiírja a négyzetet a kapott stream-re.
    void save(std::ostream& os) const;//!< Lementi a négyzetet a kapott stream-re.
    void load(std::istream& is);//!< Betölti a négyzetet a kapott stream-rõl.
    ~Negyzet();//!< Destruktor.
};

std::ostream& operator<<(std::ostream& os, const Negyzet& n);//!<

#endif
