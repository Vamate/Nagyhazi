#include "pont.h"
#include "kor.h"
#include <math.h>
#include "memtrace.h"

Pont::Pont() {
    this->X = 0; this->Y = 0;
}

Pont::Pont(double x, double y) {
    this->X = x; this->Y = y;
}

double Pont::tavolsag(Pont& p) {
    return sqrt(fabs(this->X - p.X)*fabs(this->X - p.X) + fabs(this->Y - p.Y)*fabs(this->Y - p.Y));
}

bool Pont::inKor(Kor& k) {
    return (this->tavolsag(k.getKozeppont()) <= k.getSugar());
}

std::ostream& operator<<(std::ostream& os, Pont p) {
    os<<"("<<p.X<<"|"<<p.Y<<")";
    return os;
}

std::istream& operator>>(std::istream& is, Pont& p) {
    char a;
    is>>a>>p.X>>a>>p.Y>>a;
    return is;
}
