#ifndef TAROLO_H
#define TAROLO_H
#include "alakzat.h"
#include "negyzet.h"
#include "kor.h"
#include "haromszog.h"

/*! Alakzattároló osztály. Dinamikusan tárol és kezel alakzatokat. */
class AlakzatTarolo {
private:
    Alakzat** tomb;
    int num;
public:
    AlakzatTarolo() : num(0){};
    void add(Alakzat* a);//!< Alakzat hozzáadása..
    void kivesz(int index);//!<Alakzat eltávolítása.
    Alakzat* beolvas_egyet(std::istream& is);//!< Egy alakzat beolvasása az adott stream-rõl.
    void beolvas(const char* f);//!< Az összes alakzat beolvasása fájlból.
    void hozzaolvas(const char* f);//!< Az összes alakzat eddigiekhez való hozzáadása fájlból.
    void szurKorTart(Kor& k);//!<A tárolt alakzatok szûrése az alapján, hogy benne vannak-e egy körben.
    void szurKorTart(Pont& kp, double sugar);//!< A tárolt alakzatok szûrése az alapján, hogy benne vannak-e egy körben.
    void szurPontTart(Pont& p);//!< A tárolt alakzatok szûrése az alapján, hogy tartalmaznak-e egy pontot.
    void kiir(const char* f);//!< A tárolt alakzatok kiírása fájlba.
    void kiirkonzol();//!< A tárolt alakzatok kiírása konzolra.
    Alakzat* operator [](int i) {return tomb[i];}//!< Indexelõ operátor, visszaadja az adott alakzatot.
    ~AlakzatTarolo();//!< Destruktor.
};


#endif

