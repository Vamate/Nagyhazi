#include "kor.h"
#include "memtrace.h"

Kor::Kor(Pont& kp, Pont& cs) : Alakzat(kp){
    this->sugar = kp.tavolsag(cs);
}

Kor::Kor(Pont& kp, double sugar) : Alakzat(kp){
    this->sugar = sugar;
}

double Kor::getSugar() {
    return this->sugar;
}

bool Kor::inKor(Pont& kp, double sugar) {
    return (kp.tavolsag(this->kozeppont) <= (sugar-this->sugar));
}

bool Kor::inKor(Kor& k) {
    return this->inKor(k.getKozeppont(), k.getSugar());
}

bool Kor::tartalmaz(Pont& p) {
    return p.inKor(*this);
}

void Kor::kiir(std::ostream& os) const{
    os<<"[Kor] kozeppont: "<< kozeppont <<", sugar: "<< sugar;
    os<<std::endl;
}

void Kor::save(std::ostream& os) const{
    os << "circle" << ' ' << sugar << ' ' << kozeppont << std::endl;
}

void Kor::load(std::istream& is) {
    is>>sugar>>kozeppont;
}

std::ostream& operator<<(std::ostream& os, const Kor& k) {
    k.kiir(os);
    return os;
}
