#include <iostream>
#include "memtrace.h"
#include "menu.h"
#include "tester.h"

using namespace std;

int main() {
    Menu menu; Tester tester;
    menu.kiir(Fomenu);
    if(!tester.test("kimenet.txt", "elvart_kimenet.txt")){
        cout<<"Hibas teszt"<<endl;
    } else {
        cout<<"Sikeres teszt"<<endl;
    }
    return 0;
}
