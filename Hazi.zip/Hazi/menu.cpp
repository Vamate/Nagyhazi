#include "menu.h"

using namespace std;

void Menu::kiir(MenuPont m) {
    switch(m) {
    case Fomenu:
        fomenu();
        break;
    case KHozzaad:
        khozzaad();
        break;
    case FHozzaad:
        fhozzaad();
        break;
    case FBeolvas:
        fbeolvas();
        break;
    case KKiir:
        kkiir();
        break;
    case FKiir:
        fkiir();
        break;
    case Szures:
        szures();
        break;
    default:
        cout<<"Error van..."<<endl;
        kilepes();
        break;
    }
}

void Menu::teker() {
    for(int i = 0; i < 5; i++) cout<<endl;
}

void Menu::fomenu() {
    if(onoff) teker();
    int choice = -1;
    if(onoff) {
        cout << "Menu\n-------------------\n";
        cout << "1.) Alakzat hozzaadasa konzolbol\n";
        cout << "2.) Alakzatok hozzaadasa fajlbol\n";
        cout << "3.) Alakzatok beolvasasa fajlbol\n";
        cout << "4.) Alakzatok kiirasa konzolra\n";
        cout << "5.) Alakzatok kiirasa fajlba\n";
        cout << "6.) Alakzatok szurese\n";
        cout << "7.) Menu ki-/bekapcsolasa\n";
        cout << "8.) Kilepes\n-----------------\nMenupont: ";
    }
    cin >> choice;
    cout<<"Valasztas:"<< choice<<endl;
    if(onoff) teker();
    switch(choice) {
    case 1:
        khozzaad();
        break;
    case 2:
        fhozzaad();
        break;
    case 3:
        fbeolvas();
        break;
    case 4:
        kkiir();
        break;
    case 5:
        fkiir();
        break;
    case 6:
        szures();
        break;
    case 7:
        onoff = !onoff;
        fomenu();
        break;
    case 8:
        kilepes();
        break;
    default:
        cout<<"Error van..."<<endl;
        kilepes();
        break;
    }
}

void Menu::khozzaad() {
    int a;
    if(onoff) {
        cout<<"Alakzat tipusa:\n-------------------\n1.)Kor\n2.)Haromszog\n3.)Negyzet\n";
        cout<<"-------------------\nMenupont: ";
    } cin>>a; Pont k, cs;
    if(onoff) cout<<"Alakzat kozeppontja (X|Y) formatumban: ";
    cin>>k;
    if(onoff) cout<<"Alakzat egyik csucsa (X|Y) formatumban: ";
    cin>>cs;
    if(a == 1) tarol.add(new Kor(k, cs));
    if(a == 2) tarol.add(new Haromszog(k, cs));
    if(a == 3) tarol.add(new Negyzet(k, cs));
    fomenu();
}

void Menu::fhozzaad() {
    if(onoff) cout<<"Fajl neve: ";
    std::string a; cin>>a;
    tarol.hozzaolvas(a.c_str());
    fomenu();
}

void Menu::fbeolvas() {
    if(onoff) cout<<"Fajl neve: ";
    std::string a; cin>>a;
    tarol.beolvas(a.c_str());
    fomenu();
}

void Menu::kkiir() {
    tarol.kiirkonzol();
    fomenu();
}

void Menu::fkiir() {
    if(onoff) cout<<"Fajl neve: ";
    std::string a; cin>>a;
    tarol.kiir(a.c_str());
    fomenu();
}

void Menu::szures() {
    int a;
    if(onoff) {
        cout<<"Szures tipusa:\n-------------------\n1.)Benne van-e egy korben?\n2.)Tartalmaz-e egy pontot?\n";
        cout<<"-------------------\nMenupont: ";
    }
    cin>>a; Pont k, kp;
    if(a == 1) {
        if(onoff) cout<<"Kor kozeppontja (X|Y) formatumban: ";
        cin>>k;
        if(onoff)  cout<<"Kor sugara: ";
        double s;cin>>s;
        tarol.szurKorTart(k, s);
    }if(a == 2) {
        if(onoff) cout<<"Pont (X|Y) formatumban: ";
        cin>>kp;
        tarol.szurPontTart(kp);
    }
    fomenu();
}

void Menu::kilepes() {
    cout<<"Viszlat!";
}



