#ifndef HAROMSZOG_H
#define HAROMSZOG_H
#include "alakzat.h"

class Pont;
class Kor;

/*! Háromszög osztály, Alakzatból származtatott. */
class Haromszog : public Alakzat {
private:
    Pont* csucsok;
public:
    Haromszog();//!< Alapértelmezett konstruktor.
    Haromszog(Pont& kp, Pont& cs);//!< Konstruktor középpontal és egy csúccsal.
    void data(Pont& kp, Pont& cs);//!< Háromszög középpontjából és egy csúcsából a többi csúcs kiszámítása.
    virtual bool inKor(Pont& kp, double sugar);//!< Megmondja, hogy a háromszög benne van-e egy körben.
    virtual bool inKor(Kor& k);//!< Megmondja, hogy a háromszög benne van-e egy körben.
    virtual bool tartalmaz(Pont& p);//!< Megmondja, hogy a háromszög tartalmaz-e egy pontot.
    Pont operator [](int i) const {return csucsok[i];}//!< Indexelõ operátor visszaadja a háromszög adott csúcsát.
    void kiir(std::ostream& os) const;//!< Kiírja a háromszöget a kapott stream-re.
    void save(std::ostream& os) const;//!< Lementi a háromszöget a kapott stream-re.
    void load(std::istream& is);//!< Betölti a háromszöget a kapott stream-rõl.
    ~Haromszog();//!< Destruktor.
};

std::ostream& operator<<(std::ostream& os,const Haromszog& h);//!<

#endif

