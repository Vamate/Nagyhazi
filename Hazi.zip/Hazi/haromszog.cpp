#include "haromszog.h"
#include "kor.h"
#include <math.h>
#define PI 3.14159265
#include "memtrace.h"


Haromszog::Haromszog(Pont& kp, Pont& cs) : Alakzat(kp) {
    this->csucsok = new Pont[3];
    this->data(kp, cs);
}

Haromszog::Haromszog(){
    this->csucsok = new Pont[3];
}

void Haromszog::data(Pont& kp, Pont& cs) {
    this->csucsok[0] = cs;
    for(int i = 1; i < 3; i++)
        this->csucsok[i] = Pont(cos(120.0 * PI / 180.0) * (this->csucsok[i-1].X-kp.X) - sin(120.0 * PI / 180.0) * (this->csucsok[i-1].Y-kp.Y) + kp.X, sin(120.0 * PI / 180.0) * (this->csucsok[i-1].X-kp.X) + cos(120.0 * PI / 180.0) * (this->csucsok[i-1].Y-kp.Y) + kp.Y);
}

bool Haromszog::inKor(Kor& k) {
    for(int i = 0; i < 3; i++) if(!this->csucsok[i].inKor(k)) return false;
    return true;
}

bool Haromszog::inKor(Pont& kp, double sugar) {
    Kor k(kp, sugar);
    return this->inKor(k);
}

bool Haromszog::tartalmaz(Pont& p) {
    Pont p0 = (*this)[0]; Pont p1 = (*this)[1]; Pont p2 = (*this)[2];
    double A = 0.5 * (-p1.Y * p2.X + p0.Y * (-p1.X + p2.X) + p0.X * (p1.Y - p2.Y) + p1.X * p2.Y);
    double sign = A < 0 ? -1 : 1;
    double s = (p0.Y * p2.X - p0.X * p2.Y + (p2.Y - p0.Y) * p.X + (p0.X - p2.X) * p.Y) * sign;
    double t = (p0.X * p1.Y - p0.Y * p1.X + (p0.Y - p1.Y) * p.X + (p1.X - p0.X) * p.Y) * sign;
    return (s > 0) && (t > 0) && ((s + t) < 2 * A * sign);
}

Haromszog::~Haromszog() {
    delete[] this->csucsok;
}

void Haromszog::kiir(std::ostream& os) const{
    os<<"[Haromszog] kozeppont: "<<kozeppont<<", csucsok: ";
    for(int i = 0; i < 3; i ++) os<<csucsok[i]<<" ";
    os<<std::endl;
}

void Haromszog::save(std::ostream& os) const{
    os << "triangle" << ' ' << kozeppont<<' '<<csucsok[0];
    os<<std::endl;
}

void Haromszog::load(std::istream& is) {
    Pont p;
    is>>kozeppont>>p;
    this->data(kozeppont, p);
}

std::ostream& operator<<(std::ostream& os, const Haromszog& h) {
    h.kiir(os);
    return os;
}
