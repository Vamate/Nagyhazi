#include "alakzat.h"
#include "memtrace.h"

Pont& Alakzat::getKozeppont(){
    return kozeppont;
}
