#ifndef ALAKZAT_H
#define ALAKZAT_H
#include "pont.h"

class Kor;

/*! Absztrakt alakzat õsosztály, ebbõl örökölnek a különbözõ alakzatok. */
class Alakzat {
protected:
    Pont kozeppont;/*!< Alakzat középpontja */
public:
    Alakzat(){};
    Alakzat(Pont& kp) :kozeppont(kp) {};//!< Konstruktor megadott középponttal.
    virtual bool inKor(Pont& kp, double sugar) = 0;//!< Tisztán virtuális függvény. Megmondja, hogy az alakzat benne van-e egy körben.
    virtual bool inKor(Kor& k) = 0;//!< Tisztán virtuális függvény. Megmondja, hogy az alakzat benne van-e egy körben.
    virtual bool tartalmaz(Pont& p) = 0;//!< Tisztán virtuális függvény. Megmondja, hogy az alakzat tartalmaz-e egy pontot.
    Pont& getKozeppont();//!< Középpont getter függvénye.
    virtual void kiir(std::ostream& os) const = 0;//!< Tisztán virtuális függvény. Kiírja az alakzatot a kapott stream-re.
    virtual void save(std::ostream& os) const = 0;//!< Tisztán virtuális függvény. Lementi az alakzatot a kapott stream-re.
    virtual void load(std::istream& is) = 0;//!< Tisztán virtuális függvény. Betölti az alakzatot a kapott stream-rõl.
    virtual ~Alakzat() {}//!< Virtuális destruktor.
};

#endif
