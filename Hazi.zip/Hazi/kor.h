#ifndef KOR_H
#define KOR_H
#include "alakzat.h"

class Pont;

/*! Kör osztály, Alakzatból származtatott. */
class Kor : public Alakzat{
private:
    double sugar;
public:
    Kor(){};//!< Alapértelmezett konstruktor.
    Kor(Pont& kp, Pont& cs);//!< Alapértelmezett konstruktor.
    Kor(Pont& kp, double sugar);//!< Konstruktor középpontal és sugárral.
    double getSugar();//!< A sugár getter függvénye.
    virtual bool inKor(Pont& kp, double sugar);//!< Megmondja, hogy a kör benne van-e egy körben.
    virtual bool inKor(Kor& k);//!< Megmondja, hogy a kör benne van-e egy körben.
    virtual bool tartalmaz(Pont& p);//!< Megmondja, hogy a kör tartalmaz-e egy pontot.
    void kiir(std::ostream& os) const;//!< Kiírja a kört a kapott stream-re.
    void save(std::ostream& os) const;//!< Lementi a kört a kapott stream-re.
    void load(std::istream& is);//!< Betölti a kört a kapott stream-rõl.
};

std::ostream& operator<<(std::ostream& os, Kor k);//!<

#endif
