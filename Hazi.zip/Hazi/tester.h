#ifndef TESTER_H
#define TESTER_H
#include <iostream>

/*! Teszter oszt�ly. G�pi tesztel�st hajt v�gre. */
class Tester {
public:
    bool test(const char* p1, const char* p2);//!< K�t f�jl tartalm�nak egyez�s�t vizsg�l� f�ggv�ny.
};

#endif // TESTER_H
