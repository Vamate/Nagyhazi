#ifndef MENU_H
#define MENU_H
#include "tarolo.h"

/*! Men�pontokat tartalmaz� enum. */
enum MenuPont {Fomenu, KHozzaad, FHozzaad, FBeolvas,
                KKiir, FKiir, Szures};

/*! Men� oszt�ly. */
class Menu {
    AlakzatTarolo tarol;
    bool onoff;
    void teker();
    void fomenu();
    void khozzaad();
    void fhozzaad();
    void fbeolvas();
    void kkiir();
    void fkiir();
    void szures();
    void kilepes();
public:
    Menu() :onoff(true) {}//!< Konstruktor.
    void kiir(MenuPont m);//!< Ki�r egy adott men�pontot..
};
#endif // MENU_H
