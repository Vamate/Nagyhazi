#ifndef PONT_H
#define PONT_H
#include <iostream>

class Kor;

/*! Pontot t�rol� oszt�ly */
class Pont {
public:
    double X, Y;
    Pont();//!< Alap�rtelmezett konstruktor.
    Pont(double x, double y);//!< Konstruktor koordin�t�kkal.
    double tavolsag(Pont& p);//!< Megadja egy m�sik pontt�l val� t�vols�g�t a pontnak.
    bool inKor(Kor& k);//!< Megmondja hogy a pont benne van-e egy k�rben.
};

std::ostream& operator<<(std::ostream& os, Pont p);//!<
std::istream& operator>>(std::istream& is, Pont& p);//!<


#endif
