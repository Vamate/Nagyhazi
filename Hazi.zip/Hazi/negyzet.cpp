#include "negyzet.h"
#include "kor.h"
#include "memtrace.h"

Negyzet::Negyzet(Pont& kp, Pont& cs) : Alakzat(kp) {
    this->csucsok = new Pont[4];
    this->data(kp, cs);
}

Negyzet::Negyzet(){
    this->csucsok = new Pont[4];
}

void Negyzet::data(Pont& kp, Pont& cs) {
    this->csucsok[0] = cs;
    for(int i = 1; i < 4; i++) this->csucsok[i] = Pont(-(this->csucsok[i-1].Y-kp.Y) + kp.X, (this->csucsok[i-1].X-kp.X) + kp.Y);
}

bool Negyzet::inKor(Kor& k) {
    for(int i = 0; i < 4; i++) if(!this->csucsok[i].inKor(k)) return false;
    return true;
}

bool Negyzet::inKor(Pont& kp, double sugar) {
    Kor k(kp, sugar);
    return this->inKor(k);
}

bool Negyzet::tartalmaz(Pont& p) {
    bool a, b;
    Pont p0 = (*this)[0]; Pont p1 = (*this)[1]; Pont p2 = (*this)[2];
    double A = 0.5 * (-p1.Y * p2.X + p0.Y * (-p1.X + p2.X) + p0.X * (p1.Y - p2.Y) + p1.X * p2.Y);
    double sign = A < 0 ? -1 : 1;
    double s = (p0.Y * p2.X - p0.X * p2.Y + (p2.Y - p0.Y) * p.X + (p0.X - p2.X) * p.Y) * sign;
    double t = (p0.X * p1.Y - p0.Y * p1.X + (p0.Y - p1.Y) * p.X + (p1.X - p0.X) * p.Y) * sign;
    a = s > 0 && t > 0 && (s + t) < 2 * A * sign;
    p0 = (*this)[0]; p1 = (*this)[2]; p2 = (*this)[3];
    A = 0.5 * (-p1.Y * p2.X + p0.Y * (-p1.X + p2.X) + p0.X * (p1.Y - p2.Y) + p1.X * p2.Y);
    sign = A < 0 ? -1 : 1;
    s = (p0.Y * p2.X - p0.X * p2.Y + (p2.Y - p0.Y) * p.X + (p0.X - p2.X) * p.Y) * sign;
    t = (p0.X * p1.Y - p0.Y * p1.X + (p0.Y - p1.Y) * p.X + (p1.X - p0.X) * p.Y) * sign;
    b = s > 0 && t > 0 && (s + t) < 2 * A * sign;
    return (a || b);
}

Negyzet::~Negyzet() {
    delete[] this->csucsok;
}

void Negyzet::kiir(std::ostream& os) const{
    os<<"[Negyzet] kozeppont: "<<kozeppont<<", csucsok: ";
    for(int i = 0; i < 4; i ++) os<<csucsok[i]<<" ";
    os<<std::endl;
}

void Negyzet::save(std::ostream& os) const{
    os << "rectangle" << ' ' << kozeppont<<' '<<csucsok[0];
    os<<std::endl;
}

void Negyzet::load(std::istream& is) {
    Pont p;
    is>>kozeppont>>p;
    this->data(kozeppont,p);
}

std::ostream& operator<<(std::ostream& os,  const Negyzet& n) {
    n.kiir(os);
    return os;
}
